import { useState } from "react";

import Header from "./components/layout/Header";

import {
  HP_PRODUCTS,
  OPPO_CARE_PRODUCTS,
  IOT_PRODUCTS,
  FINANCING_PROVIDERS,
  type ProductItem,
} from "./data";

import { calculateSimulation } from "./engine/calculateSimulation";

import TenorSelector from "./components/selector/TenorSelector";

export default function App() {
  const [platform, setPlatform] = useState(FINANCING_PROVIDERS[0].name);
  const [selectedModel, setSelectedModel] = useState(HP_PRODUCTS[1].model);
  const [selectedOppoCare, setSelectedOppoCare] = useState(0);
  const [selectedIot, setSelectedIot] = useState(0);
  const [tenor, setTenor] = useState<number>(3);

  const currentHp = HP_PRODUCTS.find((p: ProductItem) => p.model === selectedModel);
  const currentOppoCare = OPPO_CARE_PRODUCTS[selectedOppoCare];
  const currentIot = IOT_PRODUCTS[selectedIot];

  const provider = FINANCING_PROVIDERS.find((p) => p.name === platform)!;

  const result = calculateSimulation({
    price: currentHp?.price ?? 0,
    downPayment: 0,
    tenor,
    provider,
    oppoCarePrice: currentOppoCare?.price ?? 0,
    iotPrice: currentIot?.price ?? 0,
  });

  return (
    <div className="min-h-screen bg-slate-100 p-4 flex justify-center">
      <div className="bg-white w-full max-w-5xl rounded-2xl p-6 shadow">

        <Header />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

          {/* LEFT */}
          <div className="space-y-3">

            <select
              className="w-full border p-2 rounded"
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value)}
            >
              {HP_PRODUCTS.map((p, i) => (
                <option key={i} value={p.model}>
                  {p.model}
                </option>
              ))}
            </select>

            <select
              className="w-full border p-2 rounded"
              value={selectedOppoCare}
              onChange={(e) => setSelectedOppoCare(Number(e.target.value))}
            >
              {OPPO_CARE_PRODUCTS.map((p, i) => (
                <option key={i} value={i}>
                  {p.model}
                </option>
              ))}
            </select>

            <select
              className="w-full border p-2 rounded"
              value={selectedIot}
              onChange={(e) => setSelectedIot(Number(e.target.value))}
            >
              {IOT_PRODUCTS.map((p, i) => (
                <option key={i} value={i}>
                  {p.model}
                </option>
              ))}
            </select>

            <TenorSelector value={tenor} onChange={setTenor} />

          </div>

          {/* MIDDLE */}
          <div className="border rounded-xl p-4">
            <h2 className="font-bold mb-3">HP ONLY</h2>
            <p>Cicilan: Rp {result.hpOnly.monthlyInstallment.toLocaleString("id-ID")}</p>
          </div>

          {/* RIGHT */}
          <div className="border rounded-xl p-4 bg-emerald-50">
            <h2 className="font-bold mb-3">SMART BUNDLE</h2>
            <p>Cicilan: Rp {result.smartBundle.monthlyInstallment.toLocaleString("id-ID")}</p>
          </div>

        </div>
      </div>
    </div>
  );
}