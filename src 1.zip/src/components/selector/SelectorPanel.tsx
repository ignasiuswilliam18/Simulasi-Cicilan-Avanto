import Card from "../common/Card";
import SectionTitle from "../common/SectionTitle";

import ProviderSelector from "./ProviderSelector";
import ProductSelector from "./ProductSelector";
import OppoCareSelector from "./OppoCareSelector";
import IotSelector from "./IotSelector";
import TenorSelector from "./TenorSelector";
import PromotorForm from "./PromotorForm";
import DPInput from "./DPInput";

interface ProductOption {
  label: string;
  value: string;
}

interface SelectorPanelProps {
  state: {
    provider: string;
    providers: string[];

    product: string;
    productOptions: ProductOption[];
    productPrice: number;

    oppoCare: string;
    oppoCareOptions: string[];

    iot: string;
    iotOptions: string[];

    dp: number;
    tenor: number;

    promoterName: string;
    whatsapp: string;
  };

  actions: {
    setProvider: (value: string) => void;
    setProduct: (value: string) => void;
    setOppoCare: (value: string) => void;
    setIot: (value: string) => void;
    setDP: (value: number) => void;
    setTenor: (value: number) => void;
    setPromoterName: (value: string) => void;
    setWhatsapp: (value: string) => void;
  };
}

export default function SelectorPanel({
  state,
  actions,
}: SelectorPanelProps) {
  return (
    <Card>

      <SectionTitle
        title="Simulation Input"
        subtitle="Lengkapi data simulasi pembiayaan."
      />

      <div className="space-y-5">

        <ProviderSelector
          value={state.provider}
          providers={state.providers}
          onChange={actions.setProvider}
        />

        <ProductSelector
          value={state.product}
          options={state.productOptions}
          onChange={actions.setProduct}
        />

        {/* Harga Produk */}

        <div className="rounded-xl border bg-slate-50 p-4">

          <p className="text-xs uppercase text-slate-500">
            Harga Produk
          </p>

          <p className="mt-1 text-2xl font-bold text-emerald-700">
            Rp {state.productPrice.toLocaleString("id-ID")}
          </p>

        </div>

        <DPInput
          value={state.dp}
          max={state.productPrice}
          onChange={actions.setDP}
        />

        <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-4">

          <p className="text-xs uppercase text-slate-500">
            Sisa Pembiayaan
          </p>

          <p className="mt-1 text-2xl font-bold text-emerald-700">
            Rp {(state.productPrice - state.dp).toLocaleString("id-ID")}
          </p>

        </div>

        <OppoCareSelector
          value={state.oppoCare}
          options={state.oppoCareOptions}
          onChange={actions.setOppoCare}
        />

        <IotSelector
          value={state.iot}
          options={state.iotOptions}
          onChange={actions.setIot}
        />

        <TenorSelector
          value={state.tenor}
          onChange={actions.setTenor}
        />

        <PromotorForm
          promoterName={state.promoterName}
          whatsapp={state.whatsapp}
          onNameChange={actions.setPromoterName}
          onWhatsappChange={actions.setWhatsapp}
        />

      </div>

    </Card>
  );
}