interface HeaderProps {
  title?: string;
  subtitle?: string;
}

export default function Header({
  title = "AVANTO",
  subtitle = "Financing Simulator",
}: HeaderProps) {
  return (
    <header className="text-center mb-8">
      <h1 className="text-4xl font-black tracking-widest text-slate-900">
        {title}
      </h1>

      <p className="mt-2 text-slate-500 text-base font-medium">
        {subtitle}
      </p>
    </header>
  );
}