interface ResultCardProps {
  title: string;
  icon: string;

  providerName: string;
  productName: string;

  tenor: number;

  monthlyInstallment: number;

  productPrice: number;
  downPayment: number;
  financedAmount: number;

  admin: number;
  interest: number;

  highlight?: boolean;

  onCopy?: () => void;
}

function rupiah(value: number) {
  return "Rp " + value.toLocaleString("id-ID");
}

export default function ResultCard({
  title,
  icon,

  providerName,
  productName,

  tenor,

  monthlyInstallment,

  productPrice,
  downPayment,
  financedAmount,

  admin,
  interest,

  highlight = false,

  onCopy,
}: ResultCardProps) {
  return (
    <div
      className={`
        rounded-3xl
        border
        p-6
        shadow-sm
        transition
        duration-200
        hover:shadow-xl

        ${
          highlight
            ? "border-emerald-500 bg-emerald-50"
            : "border-slate-200 bg-white"
        }
      `}
    >
      {/* Header */}

      <div>

        <p className="text-sm font-medium text-slate-500">
          {icon} {title}
        </p>

        <p className="mt-3 text-sm text-slate-500">
          {providerName}
        </p>

        <p className="font-semibold text-slate-800">
          {productName}
        </p>

        <p className="text-sm text-slate-500">
          {tenor} Bulan
        </p>

        <h2 className="mt-4 text-4xl font-bold text-emerald-700">
          {rupiah(monthlyInstallment)}
        </h2>

        <p className="text-sm text-slate-500">
          per bulan
        </p>

      </div>

      <hr className="my-6" />

      {/* Detail */}

      <div className="space-y-3">

        <Row
          label="Harga Produk"
          value={rupiah(productPrice)}
        />

        <Row
          label="Down Payment"
          value={rupiah(downPayment)}
        />

        <Row
          label="Sisa Pembiayaan"
          value={rupiah(financedAmount)}
        />

        <Row
          label="Admin"
          value={rupiah(admin)}
        />

        <Row
          label="Bunga"
          value={rupiah(interest)}
        />

      </div>

      <button
        onClick={onCopy}
        className="
          mt-8
          w-full
          rounded-2xl
          bg-emerald-600
          py-3
          font-semibold
          text-white
          transition
          hover:bg-emerald-700
        "
      >
        📋 Copy Result
      </button>

    </div>
  );
}

interface RowProps {
  label: string;
  value: string;
}

function Row({
  label,
  value,
}: RowProps) {
  return (
    <div className="flex items-center justify-between">

      <span className="text-slate-500">
        {label}
      </span>

      <span className="font-semibold">
        {value}
      </span>

    </div>
  );
}